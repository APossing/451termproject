CREATE TABLE Users
(
    id                  VARCHAR,
    userName            VARCHAR(50),
    dateJoined          DATE,
    latitude            INTEGER,
    longitude           INTEGER,
    PRIMARY KEY         (id)
);

CREATE TABLE Friendship
(
    userId              VARCHAR,
    friendId            VARCHAR,
    PRIMARY KEY (userId,friendId),
   	FOREIGN KEY (userId) REFERENCES Users(id),
	FOREIGN KEY (friendId) REFERENCES Users(id)
);

CREATE TABLE Favourites 
(
	userId              VARCHAR,
	businessId          VARCHAR,
	PRIMARY KEY (userId,businessId),
	FOREIGN KEY (userId) REFERENCES Users(id),
	FOREIGN KEY (businessId) REFERENCES Business(id)
);

CREATE TABLE Business
(
    id                  VARCHAR,
    city                VARCHAR(50),
    businessName        VARCHAR(50),
    zipcode             INTEGER,
    businessAddress     VARCHAR(100),
    priceRange          INTEGER CHECK (priceRange>0 AND priceRange<=4),
    PRIMARY KEY         (id)
);

CREATE TABLE Attributes
(
    businessId        VARCHAR,
    attributeName        VARCHAR,
	PRIMARY KEY (businessId,attributeName),
    FOREIGN KEY (businessId) REFERENCES Business(id),
);


CREATE TABLE BelongsToCategory
(
    businessId        VARCHAR,
    categoryId        VARCHAR,
	PRIMARY KEY (businessId,categoryName),
    FOREIGN KEY (businessId) REFERENCES Business(id),
	FOREIGN KEY (categoryName) REFERENCES Category(categoryName)
);

CREATE TABLE Category
(
    categoryName  VARCHAR,
    PRIMARY KEY (id)
);

CREATE TABLE Review
(
    userId              VARCHAR,
    businessId          VARCHAR,
    reviewId            VARCHAR,
    dateCreated         DATE,
    stars               INTEGER CHECK (stars>0 AND stars<=5),
    funny               INTEGER,
    usefull             INTEGER,
    cool                INTEGER,
    reviewText          VARCHAR,
    PRIMARY KEY (userId,businessId,reviewId),
    FOREIGN KEY (userId) REFERENCES Users(id),
	FOREIGN KEY (businessId) REFERENCES Business(id)
);

CREATE TABLE Checkin
(
    businessId          VARCHAR,
    dayOfTheWeek        VARCHAR,
    timeOfDay           int,
    checkInCount        int,
    
    PRIMARY KEY (businessId,dayOfTheWeek,timeOfDay),
	FOREIGN KEY (businessId) REFERENCES Business(id)
);

