﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using HW1.DAL;
using HW1.Models;
using Npgsql;

namespace HW1.ViewModels
{
    class MainWindowVM : INotifyPropertyChanged
    {
        private NpgsqlConnection _connection;
        private Page _currentPage;
        private DataAccessLayer _dal;

        public Page CurrentPage
        {
            get => _currentPage;
            set
            {
                _currentPage = value;
                NotifyPropertyChanged("CurrentPage");
            }
        }

        private List<State> _states;

        public List<State> States
        {
            get => _states;
            set
            {
                _states = value;
                NotifyPropertyChanged("States");
            }
        }

        private State _selectedState;
        public State SelectedState
        {
            get => _selectedState;
            set
            {
                if (value != _selectedState && value != null)
                {
                    _selectedState = value;
                    SelectedCity = null;
                    Cities = _dal.GetCities(value);
                    NotifyPropertyChanged("SelectedState");
                }
            }
        }

        private City _selectedCity;

        public City SelectedCity
        {
            get => _selectedCity;
            set
            {
                _selectedCity = value;
                if (value != null)
                    Businesses = new ObservableCollection<Business>(_dal.GetBusinesses(SelectedState, SelectedCity));
                else
                    Businesses = new ObservableCollection<Business>();
                NotifyPropertyChanged("SelectedCity");
            }
        }

        private List<City> _cities;

        public List<City> Cities
        {
            get => _cities;
            set
            {
                _cities = value;
                NotifyPropertyChanged("Cities");
            }
        }

        private List<Business> _businesses;

        public ObservableCollection<Business> Businesses
        {
            get
            {
                if (_businesses != null)
                    return new ObservableCollection<Business>(_businesses);
                else
                    return null;
            }
            set
            {
                    _businesses = value.ToList();
                    NotifyPropertyChanged("Businesses");
            }
        }


        public MainWindowVM()
        {
            _dal = new DataAccessLayer();
            //Import();
            States = _dal.GetStates();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void Import()
        {
            using (StreamReader fs = new StreamReader("data.txt"))
            {
                byte[] b = new byte[1024];
                String temp = "";
                List<Tuple<String, String, String>> values = new List<Tuple<string, string, string>>();
                while (fs.Peek() >= 0)
                {
                    temp = fs.ReadLine();
                    List<String> splitString = temp.Split(',').ToList();
                    if (splitString.Count > 3)
                    {
                        for (int i = 1; i < splitString.Count - 2; i++)
                        {
                            splitString[0] += "," + splitString[i];
                        }

                        splitString[1] = splitString[splitString.Count - 2];
                        splitString[2] = splitString[splitString.Count - 1];
                    }
                    splitString[1] = splitString[1].Substring(0, splitString[1].Length - 2);
                    values.Add(new Tuple<string, string, string>(splitString[0], splitString[1], splitString[2]));
                }
                _dal.insertIntoBusiness(values);
            }

        }
    }
}
