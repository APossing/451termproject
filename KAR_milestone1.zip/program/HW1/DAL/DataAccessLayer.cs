﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW1.Models;
using Npgsql;
using HW1.DAL;

namespace HW1.DAL
{
    class DataAccessLayer
    {
        public List<State> GetStates()
        {
                List<State> states = PostgreSQLQueries.GetStates();
                return states;
        }

        public List<City> GetCities(State state)
        {
            try
            {
                List<City> cities = PostgreSQLQueries.GetCitiesByState(state);
                return cities;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public List<Business> GetBusinesses(State state, City city)
        {
            try
            {
                List<Business> businesses = PostgreSQLQueries.GetBusinesses(city, state);
                return businesses;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public void insertIntoBusiness(List<Tuple<String, String, String>> values)
        {
            PostgreSQLQueries.insertIntoBusiness(values);
        }
    }
}
