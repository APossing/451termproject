﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;
using HW1.Models;
using Npgsql;

namespace HW1.DAL
{
    internal static class PostgreSQLQueries
    {
        private static string _connectionString =
            @"Server=451termproject.postgres.database.azure.com;Database=testdb;Port=5432;User Id = admin123@451termproject;Password=Admin$123";

        internal static List<City> GetCitiesByState(State state)
        {
            List<City> cities = new List<City>();
            using (NpgsqlConnection connection = new NpgsqlConnection(_connectionString))
            {
                connection.Open();
                NpgsqlCommand cmd = connection.CreateCommand();
                cmd.CommandText = $"Select distinct city from Business where State = '{state.Name}' order by city;";
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        City city = new City();
                        city.Name = reader.GetString(0);
                        cities.Add(city);
                    }
                }
            }

            return cities;
        }

        internal static List<State> GetStates()
        {
            NpgsqlConnection connection;
            List<State> states = new List<State>();
            using (connection = new NpgsqlConnection(_connectionString))
            {
                try { connection.Open(); }
                catch(Exception ex) { return states;}

                NpgsqlCommand cmd = connection.CreateCommand();
                cmd.CommandText = "Select distinct state from business order by state;";

                NpgsqlDataReader reader;
                try { reader = cmd.ExecuteReader();}
                catch { return states;}

                while (reader.Read())
                {
                    State state = new State();
                    state.Name = reader.GetString(0);
                    states.Add(state);
                }
            }

            return states;
        }

        internal static List<Business> GetBusinesses(City city, State state)
        {
            List<Business> businesses = new List<Business>();
            using (NpgsqlConnection connection = new NpgsqlConnection(_connectionString))
            {
                connection.Open();
                NpgsqlCommand cmd = connection.CreateCommand();
                cmd.CommandText =
                    $"Select distinct Name,City,State from Business where city = '{city.Name}' and state = '{state.Name}' order by name;";
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Business business = new Business();
                        business.Name = reader.GetString(0);
                        business.CityName = reader.GetString(1);
                        business.StateName = reader.GetString(2);
                        businesses.Add(business);
                    }
                }

                return businesses;
            }
        }

        internal static void insertIntoBusiness(List<Tuple<string, string, string>> values)

        {
            List<List<Tuple<String, String, String>>> list = new List<List<Tuple<string, string, string>>>();
            for (int i = 0; i <= values.Count / 999; i++)
            {
                if (i == values.Count / 999)
                {
                    list.Add(values.GetRange(i*999, values.Count % 999));
                }
                else
                {
                    list.Add(values.GetRange(i*999, 999));
                }
            }

            foreach (var subList in list)
            {
                NpgsqlConnection connection = new NpgsqlConnection(_connectionString);
                connection.Open();
                NpgsqlCommand cmd = connection.CreateCommand();
                String formattedValueString = "";
                foreach (var val in subList)
                {
                    formattedValueString += $"('{val.Item1.Replace("'", "''")}', '{val.Item2}', '{val.Item3}'), ";
                }
                formattedValueString = formattedValueString.Replace("\"", "");
                formattedValueString = formattedValueString.Substring(0, formattedValueString.Length - 2);
                cmd.CommandText = 
                    $"insert into Business(Name, State, City) values {formattedValueString};";
                int rows = cmd.ExecuteNonQuery();
            }

        }


    }
}
