﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1.Models
{
    public class FriendsReviewBusinessRow
    {
        public String UserName { get; set; }
        public String BusinessName { get; set; }
        public String City { get; set; }
        public String Text { get; set; }
    }
}
