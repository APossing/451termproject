﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1.Models
{
    class Business
    {
        public String id { get; set; }
        public String Name { get; set; }
        public String StateName { get; set; }
        public String CityName { get; set; }
        public double Rating { get; set; }
    }
}
